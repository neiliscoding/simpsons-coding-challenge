package com.neil.coder.demo.simpsonsquotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpsonsquotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
