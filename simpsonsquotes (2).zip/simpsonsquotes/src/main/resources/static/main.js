$(document).ready(runJqueryMain);

function runJqueryMain() {
	
	var townies = [];
	var quotes = [];
	
	////////////
	
	$.ajax({
		url : "http://localhost:8083/townies/list"
	}).then(function(data) {
		console.log('townies data', data);
		townies = data;
		$('#randtownie').text(data[0].firstName);
		displayAllTownies();
	});

	$.ajax({
		url : "http://localhost:8083/quotes/list"
	}).then(function(data) {
		console.log('quotes data', data);
		quotes = data;
		$('#randquote').text(data[0].phrase);
	});

	$("#randbutton").click(function() {
		console.log("Handler for .click() called.");
		displayRandomTownie();
	});
	
	
	
	//$( "#towniecol" ).clone().appendTo( "#townierow" );
	
	////////////
	
	function makeRandomNumber(range) {
		return Math.floor(Math.random() * range);
	}
	
	function displayRandomTownie(){
		var randTownieIndex = makeRandomNumber(townies.length);
		var displayString = "";
		
		$('#randtownie').text(townies[randTownieIndex].firstName);
		
		quotes.forEach(quote => {
			//matchQuoteByTownieId(quote , randTownieIndex);
			if (quote.character == townies[randTownieIndex]._id) {
				displayString += '<q>' +  quote.phrase + "</q><br/><br/>";
			}
					
		});
		
		$('#randquote').html(displayString);
		
		//quotes.forEach(matchQuoteByTownieId(townies[randTownieIndex]._id));
	}
	
	//function matchQuoteByTownieId(quote, townieId){}
	
	function displayAllTownies(){
		console.log('displayAllTownies');
		console.log(townies);
		townies.forEach((townie , index ) => {
			console.log(townie);
			console.log(index);
			//$( "#towniecol" ).clone().appendTo( "#townierow" );
			
			if(index == 0){
				//$( "img" ).attr("src",townie.picture);
				$( "#towniecol" ).prop({'id':'towniecol0'});
				$( "#towniecol0 img" ).prop({'src':townie.picture});
				//$( "img" ).prop({'src':townie.picture, 'id':'towniecol0'});
			}
			else {
				var genId = 'towniecol' + index;
				$( "#towniecol0" ).clone().prop({'id':genId}).appendTo( "#townierow" );
				$( "#" + genId + " img" ).prop({'src':townie.picture});
				//$( "#towniecol" ).clone().appendTo( "#townierow" );
				//$( "img" ).prop({'src':townie.picture, 'id':'towniecol0'});
			}
		});
	}
	
}

