$(document).ready(runJqueryMain);

function runJqueryMain() {
	
	var townies = [];
	var quotes = [];
	
	////////////
	
	$.ajax({
		url : "http://localhost:8083/townies/list"
	}).then(function(data) {
		console.log('townies data', data);
		townies = data;
		$('#randtownie').text(data[0].firstName);
		
		
		$.ajax({
			url : "http://localhost:8083/quotes/list"
		}).then(function(data) {
			console.log('quotes data', data);
			quotes = data;
			$('#randquote').text(data[0].phrase);
			
			displayAllTownies();
		});
	});



	$("#randbutton").click(function() {
		displayRandomTownie();
	});
	
	
	  $("#search-field").on("keyup", function() {
		  console.log($(this));
		    var value = $(this).val().toLowerCase();
		    $(".tcol").filter(function() {
		    	//console.log(value);
		    	//console.log($(this).find(".card-title"));
		    	$(this).toggle($(this).find(".card-title").text().toLowerCase().indexOf(value) > -1)
		    	
		    });
		  });
	
	////////////
	
	function makeRandomNumber(range) {
		return Math.floor(Math.random() * range);
	}
	
	function displayRandomTownie(){
		var randTownieIndex = makeRandomNumber(townies.length);
		var displayString = "";
		
		$('#randtownie').text(townies[randTownieIndex].firstName);
		
		displayString = matchQuoteByTownieId(townies[randTownieIndex]._id);
		
		/*
		quotes.forEach(quote => {
			//matchQuoteByTownieId(quote , randTownieIndex);
			if (quote.character == townies[randTownieIndex]._id) {
				displayString += '<q>' +  quote.phrase + "</q><br/><br/>";
			}
					
		});
		*/
		
		$('#randquote').html(displayString);
		
		//quotes.forEach(matchQuoteByTownieId(townies[randTownieIndex]._id));
	}
	
	function matchQuoteByTownieId(townieId){
		
		var displayString = "";
		
		quotes.forEach(quote => {
			//matchQuoteByTownieId(quote , randTownieIndex);
			if (quote.character == townieId) {
				displayString += '<q>' +  quote.phrase + "</q><br/><br/>";
			}
					
		});
		//console.log('displayString');
		//console.log(displayString);
		return displayString;
	}
	
	function displayAllTownies(){
		console.log('displayAllTownies');
		console.log(townies);
		townies.forEach((townie , index ) => {
			console.log(townie);
			console.log(index);
			//$( "#towniecol" ).clone().appendTo( "#townierow" );
			var genId = 'towniecol' + index;
			
			if(index == 0){
				//$( "img" ).attr("src",townie.picture);
				
				var qts = matchQuoteByTownieId(townie._id);
				$( "#towniecol" ).prop({'id':genId});
				$( "#" + genId + " img" ).prop({'src':townie.picture});
				$( "#" + genId + " .card-title" ).text(townie.firstName);
				$( "#" + genId + " .card-text" ).html(qts);
				//$( "img" ).prop({'src':townie.picture, 'id':'towniecol0'});
			}
			else {
				
				//console.log(townie._id);
				var qts = matchQuoteByTownieId(townie._id);
				
				$( "#towniecol0" ).clone().prop({'id':genId}).appendTo( "#townierow" );
				$( "#" + genId + " img" ).prop({'src':townie.picture});
				$( "#" + genId + " .card-title" ).text(townie.firstName);
				$( "#" + genId + " .card-text" ).html(qts);
				//$( "#towniecol" ).clone().appendTo( "#townierow" );
				//$( "img" ).prop({'src':townie.picture, 'id':'towniecol0'});
			}
		});
	}
	
}

