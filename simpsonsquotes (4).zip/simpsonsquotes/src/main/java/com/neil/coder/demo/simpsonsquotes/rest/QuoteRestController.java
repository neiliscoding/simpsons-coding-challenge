package com.neil.coder.demo.simpsonsquotes.rest;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neil.coder.demo.simpsonsquotes.domain.Quote;
import com.neil.coder.demo.simpsonsquotes.service.QuoteService;

@RestController
@RequestMapping("/quotes")
public class QuoteRestController {
	
	private QuoteService quoteService;
	
	public QuoteRestController (QuoteService quoteService) {
		this.quoteService = quoteService;
		
	}
	
	@GetMapping("/list")
	public Iterable<Quote> listQuotes() {
		return quoteService.list();
	}	


	

}
