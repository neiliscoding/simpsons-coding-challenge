package com.neil.coder.demo.simpsonsquotes.repository;

import org.springframework.data.repository.CrudRepository;

import com.neil.coder.demo.simpsonsquotes.domain.Quote;

public interface QuoteRepository extends CrudRepository<Quote, Long> {

}
