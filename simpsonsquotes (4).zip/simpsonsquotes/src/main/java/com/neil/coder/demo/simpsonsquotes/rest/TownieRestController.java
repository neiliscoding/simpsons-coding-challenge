package com.neil.coder.demo.simpsonsquotes.rest;

import java.time.LocalDateTime;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.neil.coder.demo.simpsonsquotes.domain.Townie;
import com.neil.coder.demo.simpsonsquotes.service.TownieService;

@RestController
@RequestMapping("/townies")
public class TownieRestController {
	
	private TownieService townieService;
	
	public TownieRestController (TownieService townieService) {
		this.townieService = townieService;
	}
	
	@GetMapping("/list")
	public Iterable<Townie> listTownies() {
		return townieService.list();
	}	

	@GetMapping("/deletebyid")
	public void deleteTownieById(Long id) {
		townieService.deleteById(id);
	}	

}
